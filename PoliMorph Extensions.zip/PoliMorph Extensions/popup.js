// popup.js - PoliMorph Extension with Tab Independence and Session Storage

document.addEventListener("DOMContentLoaded", () => {
  const API_BASE = "https://polimorph-backend.onrender.com";

  const qs = (id) => document.getElementById(id);
  const setText = (id, txt) => {
    const el = qs(id);
    if (el) el.textContent = txt;
  };

  // Persistent Storage Management (using localStorage instead of sessionStorage)
  const saveTabData = (tabName, data) => {
    const key = `polimorph_${tabName}`;
    localStorage.setItem(key, JSON.stringify(data));
    return key;
  };

  const loadTabData = (tabName) => {
    const key = `polimorph_${tabName}`;
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : {};
  };

  const saveLanguageSettings = () => {
    const settings = getLanguageSettings();
    localStorage.setItem('polimorph_language_settings', JSON.stringify(settings));
  };

  const loadLanguageSettings = () => {
    const settings = localStorage.getItem('polimorph_language_settings');
    if (settings) {
      const parsed = JSON.parse(settings);
      qs('input-language').value = parsed.inputLang || 'english';
      qs('output-language').value = parsed.outputLang || 'english';
      qs('custom-input-language').value = parsed.customInputLang || '';
      qs('custom-output-language').value = parsed.customOutputLang || '';
      qs('hinglish-intensity').value = parsed.hinglishIntensity || 2;
      showHinglishSlider();
      showCustomLanguageInputs();
    }
  };

  const saveCurrentTabState = () => {
    const activeTab = document.querySelector('.tab-btn.active').dataset.tab;
    const tabData = {};
    
    // Save all inputs and outputs for current tab
    const inputs = document.querySelectorAll(`#${activeTab} input, #${activeTab} textarea`);
    inputs.forEach(input => {
      if (input.id) tabData[input.id] = input.value;
    });
    
    const outputs = document.querySelectorAll(`#${activeTab} pre`);
    outputs.forEach(output => {
      if (output.id) tabData[output.id] = output.textContent;
    });
    
    saveTabData(activeTab, tabData);
  };

  const loadTabState = (tabName) => {
    const data = loadTabData(tabName);
    Object.keys(data).forEach(key => {
      const element = qs(key);
      if (element) {
        element.value = data[key];
        if (element.tagName === 'PRE') {
          element.textContent = data[key];
        }
      }
    });
  };

  // Language Management
  const getLanguageSettings = () => {
    const inputLang = qs('input-language')?.value || 'english';
    const outputLang = qs('output-language')?.value || 'english';
    const hinglishIntensity = qs('hinglish-intensity')?.value || '2';
    const customInputLang = qs('custom-input-language')?.value || '';
    const customOutputLang = qs('custom-output-language')?.value || '';
    
    return {
      inputLang: inputLang === 'custom' ? customInputLang : inputLang,
      outputLang: outputLang === 'custom' ? customOutputLang : outputLang,
      hinglishIntensity: parseInt(hinglishIntensity),
      customInputLang,
      customOutputLang
    };
  };

  const showHinglishSlider = () => {
    const outputLang = qs('output-language')?.value;
    const slider = qs('hinglish-slider');
    if (slider) {
      slider.style.display = outputLang === 'hinglish' ? 'block' : 'none';
    }
  };

  const showCustomLanguageInputs = () => {
    const inputLang = qs('input-language')?.value;
    const outputLang = qs('output-language')?.value;
    const customInput = qs('custom-input-language');
    const customOutput = qs('custom-output-language');
    
    if (customInput) {
      customInput.style.display = inputLang === 'custom' ? 'block' : 'none';
    }
    if (customOutput) {
      customOutput.style.display = outputLang === 'custom' ? 'block' : 'none';
    }
  };

  // Generic POST helper that returns parsed JSON or throws a helpful error
  async function postJSON(path, body) {
    const url = API_BASE + path;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const text = await res.text().catch(() => "");
    const ctype = res.headers.get("content-type") || "";

    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText} - ${text.slice(0, 400)}`);
    }

    if (!ctype.includes("application/json")) {
      // backend returned HTML or plain text — include snippet
      throw new Error("Server didn't return JSON. Response snippet: " + text.slice(0, 400));
    }

    try {
      return JSON.parse(text);
    } catch (err) {
      throw new Error("Invalid JSON from server: " + (text ? text.slice(0, 400) : "<empty>"));
    }
  }

  // --- Copy buttons (safe)
  document.querySelectorAll(".copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.target;
      const text = qs(targetId)?.textContent || "";
      navigator.clipboard.writeText(text).then(() => {
        const prev = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(() => (btn.textContent = prev || "Copy"), 1300);
      }).catch(() => {
        btn.textContent = "Fail";
        setTimeout(() => (btn.textContent = "Copy"), 1300);
      });
    });
  });

  // --- Tabs with State Management ---
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      // Save current tab state
      saveCurrentTabState();
      
      // Switch tabs
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      const el = document.getElementById(tab);
      if (el) el.classList.add("active");
      
      // Load new tab state
      loadTabState(tab);
    });
  });

  // Language toggle functionality
  const languageToggleBtn = qs('language-toggle-btn');
  const languageSection = qs('language-section');
  
  if (languageToggleBtn && languageSection) {
    languageToggleBtn.addEventListener('click', () => {
      const isVisible = languageSection.style.display !== 'none';
      languageSection.style.display = isVisible ? 'none' : 'block';
      languageToggleBtn.classList.toggle('active', !isVisible);
    });
  }

  // Language selection handlers
  qs('output-language')?.addEventListener('change', () => {
    showHinglishSlider();
    showCustomLanguageInputs();
    saveLanguageSettings();
  });
  
  qs('input-language')?.addEventListener('change', () => {
    showCustomLanguageInputs();
    saveLanguageSettings();
  });
  
  qs('custom-input-language')?.addEventListener('input', saveLanguageSettings);
  qs('custom-output-language')?.addEventListener('input', saveLanguageSettings);
  qs('hinglish-intensity')?.addEventListener('input', saveLanguageSettings);

  // Context receiver role handler
  qs('context-receiver')?.addEventListener('change', () => {
    const customInput = qs('custom-context-receiver');
    if (customInput) {
      customInput.style.display = qs('context-receiver').value === 'custom' ? 'block' : 'none';
    }
  });

  // Clear all functionality
  const clearAllBtn = qs('clear-all-btn');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to clear all data from all tabs? This action cannot be undone.')) {
        // Clear all localStorage data
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
          if (key.startsWith('polimorph_')) {
            localStorage.removeItem(key);
          }
        });
        
        // Clear all input fields
        const allInputs = document.querySelectorAll('input, textarea');
        allInputs.forEach(input => {
          if (input.id !== 'context-receiver') { // Keep receiver as 'me'
            input.value = '';
          }
        });
        
        // Clear all output areas
        const allOutputs = document.querySelectorAll('pre');
        allOutputs.forEach(output => {
          output.textContent = '';
        });
        
        // Reset language settings
        qs('input-language').value = 'english';
        qs('output-language').value = 'english';
        qs('custom-input-language').value = '';
        qs('custom-output-language').value = '';
        qs('hinglish-intensity').value = '2';
        qs('context-receiver').value = 'me';
        
        showHinglishSlider();
        showCustomLanguageInputs();
        saveLanguageSettings();
        
        alert('All data has been cleared successfully!');
      }
    });
  }
  
  showHinglishSlider(); // Initial call
  showCustomLanguageInputs(); // Initial call

  // --- GENERAL TAB HANDLERS ---
  
  // General utility buttons
  const generalButtons = [
    { id: 'humanize-btn', endpoint: '/humanize' },
    { id: 'paraphrase-btn', endpoint: '/paraphrase' },
    { id: 'summarize-btn', endpoint: '/summarize' },
    { id: 'elaborate-btn', endpoint: '/elaborate' },
    { id: 'grammar-btn', endpoint: '/grammar' },
    { id: 'simplify-btn', endpoint: '/simplify' }
  ];

  generalButtons.forEach(({ id, endpoint }) => {
    const btn = qs(id);
    if (btn) {
      btn.addEventListener("click", async () => {
        setText("general-output", "⏳ Processing...");
        const text = qs("general-input")?.value || "";
        const langSettings = getLanguageSettings();
        try {
          const data = await postJSON(endpoint, { text, ...langSettings });
          setText("general-output", data.result || JSON.stringify(data));
        } catch (err) {
          setText("general-output", "❌ " + err.message);
        }
      });
    }
  });

  // Custom role morphing
  const morphRoleBtn = qs("morph-role-btn");
  if (morphRoleBtn) {
    morphRoleBtn.addEventListener("click", async () => {
      setText("general-output", "⏳ Processing...");
      const text = qs("general-input")?.value || "";
      const senderDropdown = qs("sender-dropdown")?.value || "";
      const receiverDropdown = qs("receiver-dropdown")?.value || "";
      const customSender = qs("custom-sender")?.value || "";
      const customReceiver = qs("custom-receiver")?.value || "";
      const langSettings = getLanguageSettings();
      
      const senderRole = senderDropdown || customSender;
      const receiverRole = receiverDropdown || customReceiver;
      
      try {
        const data = await postJSON("/customrole", { 
          text, 
          senderRole, 
          receiverRole, 
          ...langSettings 
        });
        setText("general-output", data.result || JSON.stringify(data));
      } catch (err) {
        setText("general-output", "❌ " + err.message);
      }
    });
  }

  // --- FORMATTING TAB HANDLERS ---
  
  const formattingButtons = [
    { id: 'paragraph-to-bullets-btn', endpoint: '/paragraph-to-bullets' },
    { id: 'bullets-to-paragraph-btn', endpoint: '/bullets-to-paragraph' },
    { id: 'table-to-text-btn', endpoint: '/table-to-text' },
    { id: 'text-to-table-btn', endpoint: '/text-to-table' },
    { id: 'checklist-btn', endpoint: '/checklist' },
    { id: 'word-limit-btn', endpoint: '/word-limit' },
    { id: 'language-convert-btn', endpoint: '/language-convert' },
    { id: 'delete-all-btn', endpoint: '/delete-all' },
    { id: 'replace-all-btn', endpoint: '/replace-all' },
    { id: 'prompt-it-btn', endpoint: '/prompt-it' }
  ];

  formattingButtons.forEach(({ id, endpoint }) => {
    const btn = qs(id);
    if (btn) {
      btn.addEventListener("click", async () => {
        setText("formatting-output", "⏳ Processing...");
        const text = qs("formatting-input")?.value || "";
        const langSettings = getLanguageSettings();
        
        let extraData = {};
        if (id === 'paragraph-to-bullets-btn') {
          extraData.bulletStyle = qs("bullet-style")?.value || "step";
        } else if (id === 'word-limit-btn') {
          extraData.wordLimit = parseInt(qs("word-limit")?.value || "100");
        } else if (id === 'delete-all-btn') {
          extraData.deleteText = qs("delete-text")?.value || "";
        } else if (id === 'replace-all-btn') {
          extraData.findText = qs("replace-find-text")?.value || "";
          extraData.replaceText = qs("replace-with-text")?.value || "";
        }
        
        try {
          const data = await postJSON(endpoint, { text, ...langSettings, ...extraData });
          setText("formatting-output", data.result || JSON.stringify(data));
        } catch (err) {
          setText("formatting-output", "❌ " + err.message);
        }
      });
    }
  });

  // Show/hide special options
  qs('paragraph-to-bullets-btn')?.addEventListener('click', () => {
    qs('bullet-options').style.display = 'block';
  });
  
  qs('word-limit-btn')?.addEventListener('click', () => {
    qs('word-limit-options').style.display = 'block';
  });
  
  qs('delete-all-btn')?.addEventListener('click', () => {
    qs('delete-options').style.display = 'block';
  });
  
  qs('replace-all-btn')?.addEventListener('click', () => {
    qs('replace-options').style.display = 'block';
  });

  // Custom formatting
  const customFormatBtn = qs("custom-format-btn");
  if (customFormatBtn) {
    customFormatBtn.addEventListener("click", async () => {
      setText("formatting-output", "⏳ Processing...");
      const text = qs("formatting-input")?.value || "";
      const request = qs("custom-format-request")?.value || "";
      const langSettings = getLanguageSettings();
      
      try {
        const data = await postJSON("/custom-format", { text, request, ...langSettings });
        setText("formatting-output", data.result || JSON.stringify(data));
      } catch (err) {
        setText("formatting-output", "❌ " + err.message);
      }
    });
  }

  // --- TONE SHIFTING TAB HANDLERS ---
  
  const toneButtons = [
    { id: 'formal-academic-btn', tone: 'formal academic' },
    { id: 'professional-btn', tone: 'professional/business' },
    { id: 'conversational-btn', tone: 'conversational' },
    { id: 'friendly-btn', tone: 'friendly' },
    { id: 'persuasive-btn', tone: 'persuasive' },
    { id: 'inspirational-btn', tone: 'inspirational' },
    { id: 'humorous-btn', tone: 'humorous and witty' },
    { id: 'empathetic-btn', tone: 'empathetic' },
    { id: 'sincere-btn', tone: 'sincere' },
    { id: 'simplified-btn', tone: 'simplified' },
    { id: 'storyfy-btn', tone: 'storyfy' },
    { id: 'exampleify-btn', tone: 'exampleify' }
  ];

  toneButtons.forEach(({ id, tone }) => {
    const btn = qs(id);
    if (btn) {
      btn.addEventListener("click", async () => {
        setText("tone-output", "⏳ Processing...");
        const text = qs("tone-input")?.value || "";
        const langSettings = getLanguageSettings();
        
        try {
          const data = await postJSON("/tone", { text, tone, ...langSettings });
          setText("tone-output", data.result || JSON.stringify(data));
        } catch (err) {
          setText("tone-output", "❌ " + err.message);
        }
      });
    }
  });

  // Custom tone
  const customToneBtn = qs("custom-tone-btn");
  if (customToneBtn) {
    customToneBtn.addEventListener("click", async () => {
      setText("tone-output", "⏳ Processing...");
      const text = qs("tone-input")?.value || "";
      const customTone = qs("custom-tone-input")?.value || "";
      const langSettings = getLanguageSettings();
      
      try {
        const data = await postJSON("/tone", { text, tone: customTone, ...langSettings });
        setText("tone-output", data.result || JSON.stringify(data));
      } catch (err) {
        setText("tone-output", "❌ " + err.message);
      }
    });
  }

  // --- CONTEXT AWARE TAB HANDLERS ---
  
  const analyzeContextBtn = qs("analyze-context-btn");
  if (analyzeContextBtn) {
    analyzeContextBtn.addEventListener("click", async () => {
      // Update button state
      const originalText = analyzeContextBtn.innerHTML;
      analyzeContextBtn.innerHTML = '<span class="btn-icon">⏳</span>Generating...';
      analyzeContextBtn.disabled = true;
      
      // Set loading states
      setText("response-1", "⏳ Generating direct response...");
      setText("response-2", "⏳ Generating diplomatic response...");
      setText("response-3", "⏳ Generating strategic response...");
      setText("sender-thoughts", "⏳ Analyzing sender's intent...");
      setText("meaning-for-you", "⏳ Analyzing impact...");
      setText("sender-perception", "⏳ Analyzing perception...");
      
      const text = qs("context-input")?.value || "";
      const sender = qs("context-sender")?.value || "";
      const aim = qs("conversation-aim")?.value || "";
      const receiverDropdown = qs("context-receiver")?.value || "me";
      const customReceiver = qs("custom-context-receiver")?.value || "";
      const receiver = receiverDropdown === 'custom' ? customReceiver : receiverDropdown;
      const langSettings = getLanguageSettings();
      
      if (!text.trim()) {
        setText("response-1", "❌ Please enter a message to analyze");
        setText("response-2", "❌ Please enter a message to analyze");
        setText("response-3", "❌ Please enter a message to analyze");
        setText("sender-thoughts", "❌ Please enter a message to analyze");
        setText("meaning-for-you", "❌ Please enter a message to analyze");
        setText("sender-perception", "❌ Please enter a message to analyze");
        
        // Reset button
        analyzeContextBtn.innerHTML = originalText;
        analyzeContextBtn.disabled = false;
        return;
      }
      
      try {
        // Make both API calls in parallel
        const [responsesData, insightsData] = await Promise.all([
          postJSON("/context-analyze", { text, sender, receiver, aim, ...langSettings }),
          postJSON("/context-insights", { text, sender, receiver, aim, ...langSettings })
        ]);
        
        // Update responses
        setText("response-1", responsesData.response1 || "No response generated");
        setText("response-2", responsesData.response2 || "No response generated");
        setText("response-3", responsesData.response3 || "No response generated");
        
        // Update analysis insights
        setText("sender-thoughts", insightsData.senderIntent || "Analysis not available");
        setText("meaning-for-you", insightsData.impactOnYou || "Analysis not available");
        setText("sender-perception", insightsData.perceptionImpact || "Analysis not available");
        
      } catch (err) {
        const errorMsg = "❌ " + err.message;
        setText("response-1", errorMsg);
        setText("response-2", errorMsg);
        setText("response-3", errorMsg);
        setText("sender-thoughts", errorMsg);
        setText("meaning-for-you", errorMsg);
        setText("sender-perception", errorMsg);
      } finally {
        // Reset button
        analyzeContextBtn.innerHTML = originalText;
        analyzeContextBtn.disabled = false;
      }
    });
  }

  // --- MULTIPLE ANSWER TAB HANDLERS ---
  
  const generateVariationsBtn = qs("generate-variations-btn");
  if (generateVariationsBtn) {
    generateVariationsBtn.addEventListener("click", async () => {
      setText("answer-1", "⏳ Generating...");
      setText("answer-2", "⏳ Generating...");
      setText("answer-3", "⏳ Generating...");
      
      const text = qs("multi-input")?.value || "";
      const langSettings = getLanguageSettings();
      
      try {
        const data = await postJSON("/generate-variations", { text, ...langSettings });
        
        setText("answer-1", data.answer1 || "");
        setText("answer-2", data.answer2 || "");
        setText("answer-3", data.answer3 || "");
        setText("properties-1", data.properties1 || "");
        setText("properties-2", data.properties2 || "");
        setText("properties-3", data.properties3 || "");
      } catch (err) {
        const errorMsg = "❌ " + err.message;
        setText("answer-1", errorMsg);
        setText("answer-2", errorMsg);
        setText("answer-3", errorMsg);
      }
    });
  }

  // Regenerate individual answers
  document.querySelectorAll(".regenerate-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const target = btn.dataset.target;
      const answerId = `answer-${target}`;
      const propertiesId = `properties-${target}`;
      
      setText(answerId, "⏳ Regenerating...");
      
      const text = qs("multi-input")?.value || "";
      const properties = qs(propertiesId)?.value || "";
      const langSettings = getLanguageSettings();
      
      try {
        const data = await postJSON("/regenerate-answer", { 
          text, 
          properties, 
          answerNumber: target,
          ...langSettings 
        });
        setText(answerId, data.result || JSON.stringify(data));
      } catch (err) {
        setText(answerId, "❌ " + err.message);
      }
    });
  });


  // Load initial settings and tab state
  loadLanguageSettings();
  loadTabState('general');
  
});
